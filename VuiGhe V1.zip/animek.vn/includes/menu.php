  <header>
    <nav class="navbar">
    	<div class="navbar-container">
			<div class="navbar-header">
				<div class="navbar-brand">
					<a class="logo" onclick="window.parent.location = 'index.php';">
						<img src="/assets/img/logo.png?<?php echo date('l jS \of F Y h:i:s A'); ?>" alt="Aniraw">
					</a>
				</div>
				<div class="navbar-menu-toggle" id="navbar-toggle">
					<i class="icon-menu"></i>
				</div>
				<div class="navbar-header-user">
						        			<img class="user-avatar" id="user-avatar" src="https://i.pinimg.com/564x/3c/07/e1/3c07e100968117c181d57418813cad4c.jpg"></img>
						
	        			
	        			<div class="user-theme" id="user-theme">
							<i class="icon-sunny"></i>
						</div>
	        			<div class="user-tos" id="user-tos" onclick="window.open('/privacy-policy.php')">
							<i class="icon-information"></i>
						</div>
						
	        						</div>
			</div>
			<div class="navbar-left" id="navbar-left">
				
				<div class="navbar-search">
					<div class="search-box">
						<input type="text" name="search-box" placeholder="Tìm kiếm anime">
						<i class="icon icon-search"></i>
					</div>
					<div class="search-result" id="search-result">
						<div class="result-body"></div>
						<div class="result-noitem hidden"></div>
						<div class="loading hidden"></div>
					</div>
				</div>
				<div class="navbar-menu">
					<a class="navbar-menu-item" href="anime"><i class="icon icon-film"></i> Anime</a>
	                <a href="/yeucau" class="navbar-menu-item"  target="_blank"><i class="icon icon-news"></i> Yêu cầu phim</a>
	                <a class="navbar-menu-item" href="/bang-xep-hang"><i class="icon icon-chart"></i> BXH</a>
	                
				</div>
				<div class="navbar-close">
					<i class="icon-close"></i>
				</div>
			</div>
			<div class="navbar-right" id="navbar-right">
					    			<div class="navbar-user navbar-user-header">
		<div class="user-avatar big-avatar">
			<img src="https://i.pinimg.com/564x/3c/07/e1/3c07e100968117c181d57418813cad4c.jpg"></img>
			<div class="user-avatar-update"><i class="icon-images"></i></div>
			<input class="user-avatar-file" id="avatar-upload" type="file" name="avatar_file" accept="image/*">
		</div>
			    <div class="navbar-user-welcome">
	        <span>Chào bạn!</span>
	        <input id="user-id" type="hidden" value="406845">
			<input id="user-date" type="hidden" value="2019-03-07 23:18:15">
	    </div>
	    <div class="navbar-user-tab">
	        <div class="navbar-user-tab-item navbar-tab-information activated" data-tab="information">Thông tin</div>
	        <div class="navbar-user-tab-item navbar-tab-notification" data-tab="notification">Thông báo</div>
	        
	    </div>
	</div>
	<div class="navbar-user-body tab-information">
		<div class="navbar-user-content">
						<div class="user-item">
				<a href="/">
					<i class="icon icon-person"></i>
					Trang chủ
				</a>
			</div>
			<div class="user-item">
				<a href="/bang-xep-hang/">
					<i class="icon icon-edit"></i>
				Bảng xếp hạng
				</a>
			</div>
			<div class="user-item">
				<a href="https://www.facebook.com/SPT.Nhan">
					<i class="icon icon-unlock"></i>
					Facebook admin
				</a>
			</div>
			<hr>
			<div class="user-item">
				<a href="/yeucau">
					<i class="icon icon-film"></i>
					Yêu cầu phim
				</a>
			</div>
			<!--<div class="user-item">
				<a href="/phim-da-thich">
					<i class="icon icon-heart"></i>
					Phim 
				</a>
			</div>
			<div class="user-item">
				<a href="/phim-dang-theo-doi">
					<i class="icon icon-notifications"></i>
					Phim đang theo dõi
				</a>
			</div>
			<hr>
			
			<div class="user-item">
				<a href="https://vuighe.net/nang-cap-tai-khoan">
					<i class="icon icon-timer"></i>
					Nâng cấp VIP
				</a>
			</div>
			<div class="user-item">
				<a href="https://vuighe.net/nap-tien">
					<i class="icon icon-ribbon"></i>
					Nạp thêm VGEM (0)
				</a>
			</div>
			<div class="user-item">
				<a href="https://vuighe.net/lich-su-giao-dich">
					<i class="icon icon-time"></i>
					Lịch sử giao dịch
				</a>
			</div>
			<hr>
			<div class="logout user-item" id="logout">
				<i class="icon icon-power"></i>
				Đăng xuất
			</div>-->
			
		</div>
	</div>

	<div class="navbar-user-body tab-notification">
	<div class="notification-list">
	    <div id="thongbao"></div>
  
</div>
		<div class="notification-none hidden"></div>
		<div class="notification-more hidden">xem thêm</div>
		
	</div>

	

	<div class="loading hidden"></div>	    						<div class="navbar-close">
					<i class="icon-close"></i>
				</div>
			</div>
		</div>
    	
			
	        
        	
        
    </nav>
</header>
