<?php
    header('Content-Type: application/xml; charset=utf-8');
    include 'config.php';
?>
<urlset
      xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9
            http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
<!-- created with Free Online Sitemap Generator www.xml-sitemaps.com -->


<url>
  <loc>https://animek.vn/</loc>
  <lastmod><?php echo date('c',time()); ?></lastmod>
  <priority>1.00</priority>
</url>
<url>
  <loc>https://animek.vn/bang-xep-hang/</loc>
  <lastmod><?php echo date('c',time()); ?></lastmod>
  <priority>0.80</priority>
</url>
              <?php
				$result = mysqli_query($ketnoi,"SELECT * FROM film ORDER BY luotxem DESC LIMIT 0,8");
				if($result)
				{
				while($row = mysqli_fetch_assoc($result))
				{
				?>
<url>
  <loc>https://animek.vn/View/id/<?php echo "".$row["linkphim"].""; ?>.html?play=<?php echo "".$row["id"].""; ?></loc>
  <lastmod><?php echo date('c',time()); ?></lastmod>
  <priority>0.64</priority>
</url>
           	<?php 
				}
				}
				?>

</urlset>