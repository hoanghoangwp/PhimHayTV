
<?php
header('Content-Type: text/html;charset=utf-8');  
ob_start();
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
if((isset($_GET['aniraw']))){
    $aniraw = $_GET['aniraw'];
    
?>
<?php require ("./connect.php"); ?>
<?php if (isset($_SESSION['user_id'])) { ?>


<?php
if(isset($_GET['i'])){
        switch($_GET['i']) {
            case 1:
                echo '<script>swal("success!", "Đã thêm phim thành công!", "success");</script>';
            break;
            case 2:
                    echo '<script>swal("Failed!", "Lỗi khi add phim !", "error");
</script>';
            break;
            
            default:
                
            break;
        }
}
?>

<!DOCTYPE html>
<html>
<?php require ("./head.php"); ?>
                                               
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Vui lòng chờ...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <?php require ("menu.php"); ?>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
           
            <!-- Menu -->
            <?php require ("menu2.php"); ?>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                    &copy; 2016 - 2017 <a href="javascript:void(0);">AdminBSB - Material Design</a>.
                </div>
                <div class="version">
                    <b>Version: </b> 1.0.5
                </div>
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
       
    </section>

<?php $maxtap = "??" ;?>
<?php
if(isset($_POST['save']))
{
$tenphim = mysqli_real_escape_string($link, $_REQUEST['tenphim']);
$tap = mysqli_real_escape_string($link, $_REQUEST['tap']);
$player = mysqli_real_escape_string($link, $_REQUEST['player']);
$tentap = mysqli_real_escape_string($link, $_REQUEST['tentap']);
$thumb = mysqli_real_escape_string($link, $_REQUEST['thumb']);
$sqls = "UPDATE `film` SET `moinhat` = N'$tentap' WHERE id=$tenphim";
$sqlss = "UPDATE `film` SET `tapmoinhat` = N'$tap' WHERE id=$tenphim";
$sqlsss = "UPDATE `film` SET `thumbmoi` = N'$thumb' WHERE id=$tenphim";
$sqlssss = "UPDATE `film` SET `reg_date` = reg_date' WHERE id=$tenphim";
$sql = "INSERT INTO cactap (tenphim, tap, player, tentap, thumb) VALUES (N'$tenphim', '$tap', '$player', N'$tentap', '$thumb')";
mysql_query("set names 'utf-8'");
if(mysqli_query($link, $sql)){
    header('Location: themtapphim.php?aniraw='.$tenphim.'&i=1');
} else{
    header('Location: themtapphim.php?aniraw='.$tenphim.'&i=2');
}
if(mysqli_query($link, $sqlssss)){
    header('Location: themtapphim.php?aniraw='.$tenphim.'&i=1');
} else{
    header('Location: themtapphim.php?aniraw='.$tenphim.'&i=2');
}
if(mysqli_query($link, $sqls)){
    header('Location: themtapphim.php?aniraw='.$tenphim.'&i=1');
} else{
    header('Location: themtapphim.php?aniraw='.$tenphim.'&i=2');
} 
if(mysqli_query($link, $sqlss)){
    header('Location: themtapphim.php?aniraw='.$tenphim.'&i=1');
} else{
    header('Location: themtapphim.php?aniraw='.$tenphim.'&i=2');
} 
if(mysqli_query($link, $sqlsss)){
    header('Location: themtapphim.php?aniraw='.$tenphim.'&i=1');
} else{
    header('Location: themtapphim.php?aniraw='.$tenphim.'&i=2');
} 
// Close connection
mysqli_close($link);
exit;

}

?>
<?php
$sql4 = "SELECT * FROM film WHERE id = '$aniraw'";
if($result1 = mysqli_query($ketnoi, $sql4)){
    if(mysqli_num_rows($result1) > 0){
        while($row = mysqli_fetch_array($result1)){
            ?>
  <section class="content">
        <div class="container-fluid">
         
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>THÊM TẬP PHIM VÀO BỘ <?php echo $row['tenphim'] ; ?></h2>
                          
                        </div>
                        <div class="body">

                            <form id="form_advanced_validation" method="POST" action="">
                                <div style="display:none" class="form-group">
			        <label for="username">Chọn phim</label>
                    <select name="tenphim">
<option value="<?php echo $row['id'] ; ?>"><?php echo $row['id'] ; ?></option>

</select>
			    </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control"  min="<?php echo $row['tapmoinhat'] ; ?>" max="<?php echo $row['tongsotap'] ;  if($row['tongsotap'] == ''.$maxtap.''){
					echo '9999999';
					} ?>" name="tap" required>
                                        <label class="form-label">Viết số tập ví dụ : 1...</label>
                                    </div>
                                    <div class="help-info">Ví dụ : 1</div>
                                </div>
                                 <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" id="sharelink" name="sharelink" required>
                                        <label class="form-label">Nhập Link Player Google Drive (JWPLayer)</label>
                                    </div>
                                    <div class="help-info">Ví dụ : 2019</div>
                                </div>
                                <div style="display:none" class="form-group form-float">
                                    <div class="form-line">
                                        <input class="form-control" type="text" placeholder="Link phim của bạn (Auto Generator)" id="player" name="player" required>
                                      
                                    </div>
                                    
                                </div>
                                  
                                 <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="thumb" required>
                                        <label class="form-label">Link Ảnh Thumbnail Của Tập Phim</label>
                                    </div>
                                </div>
                                 <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="tentap" required>
                                        <label class="form-label">Tên tập phim</label>
                                    </div>
                                    <div class="help-info">Ví dụ : Cảm giác bồi hồi xuyến xao</div>
                                </div>
                                
                                <button name="save" class="btn btn-primary waves-effect" type="submit">Thêm tập phim</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Validation -->
        </div>
    </section>


 
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Jquery CountTo Plugin Js -->
    <script src="plugins/jquery-countto/jquery.countTo.js"></script>

    <!-- Morris Plugin Js -->
    <script src="plugins/raphael/raphael.min.js"></script>
    <script src="plugins/morrisjs/morris.js"></script>

    <!-- ChartJs -->
    <script src="plugins/chartjs/Chart.bundle.js"></script>

    <!-- Flot Charts Plugin Js -->
    <script src="plugins/flot-charts/jquery.flot.js"></script>
    <script src="plugins/flot-charts/jquery.flot.resize.js"></script>
    <script src="plugins/flot-charts/jquery.flot.pie.js"></script>
    <script src="plugins/flot-charts/jquery.flot.categories.js"></script>
    <script src="plugins/flot-charts/jquery.flot.time.js"></script>

    <!-- Sparkline Chart Plugin Js -->
    <script src="plugins/jquery-sparkline/jquery.sparkline.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/index.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>

        <script id="rendered-js">
          (function ($) {
  $(function () {
    var $shareLink = $('#sharelink'),
    $player = $('#player'),
    $copyButton = $('#copylinkbtn'),
    clipboard;

    $shareLink.on('keyup paste', function () {
      var link = $shareLink.val(),
      l = link.replace(/https?:\/\/drive.google.com\/file\/d\/(.+)\/(.+)/, "$1");
      if (l !== link) {
        $player.val(l);
        $copyButton.removeAttr('disabled');
      } else {
        $player.val('');
        $copyButton.attr('disabled', 'disabled');
      }
    });

    $player.on('click', function () {
      $player.select();
    });

    clipboard = new Clipboard('#copylinkbtn');
    clipboard.on('success', function (e) {
      $.notify({
        icon: 'glyphicon glyphicon-ok-circle',
        title: 'Link copied to clipboard:',
        message: e.text,
        url: e.text,
        target: '_blank' },
      {
        // settings
        type: "success",
        placement: {
          from: "top",
          align: "center" } });



      // $.notify(e.text + " copied to clipboard.");

      e.clearSelection();
    });

  });
})(jQuery);
          //# sourceURL=pen.js
        </script>
</body>

</html>
 <?php
}} ?>
	<?php } else {
	}}
	} ?>