
<?php 
ob_start();
session_start();
require ("./connect.php"); ?>
<?php if (isset($_SESSION['user_id'])) { ?>
<!DOCTYPE html>
<html>
<?php require ("./head.php"); ?>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Vui lòng chờ...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <?php require ("menu.php"); ?>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
           
            <!-- Menu -->
            <?php require ("menu2.php"); ?>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                    &copy; 2016 - 2017 <a href="javascript:void(0);">AdminBSB - Material Design</a>.
                </div>
                <div class="version">
                    <b>Version: </b> 1.0.5
                </div>
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
       
    </section>
<?php
$tieude = "";
$mota = "";
$url = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST["tieude"])) { $tieude = $_POST['tieude']; }
    if(isset($_POST["mota"])) { $mota = $_POST['mota']; }
    if(isset($_POST["url"])) { $url = $_POST['url']; }
    $sql = "UPDATE `thongtin` SET `tieude` = N'".$tieude."',`mota` = N'".$mota."',`url` = N'".$url."'";

    if (mysqli_query($conn, $sql)) {
      header("Refresh:0");
    } else {
       header("Refresh:0");
    }
}
mysqli_close($conn);
?>

  <section class="content">
        <div class="container-fluid">
         
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>CHỈNH SỬA THÔNG TIN WEBSITE</h2>
                          
                        </div>
                        <div class="body">
                                        <?php
$sql4 = "SELECT * FROM thongtin";
if($result1 = mysqli_query($ketnoi, $sql4)){
    if(mysqli_num_rows($result1) > 0){
        while($row = mysqli_fetch_array($result1)){
            ?>
                            <form id="form_advanced_validation" method="POST">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="tieude" value="<?php echo $row["tieude"]; ?>" required>
                                        <label class="form-label">Tiêu đề Website</label>
                                    </div>
                                    <div class="help-info">Ví dụ : Animek.vn - Xem anime Online chất lượng cao</div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <textarea name="mota" cols="30" rows="5" class="form-control no-resize" required="" aria-required="true"><?php echo $row["mota"]; ?></textarea>
                                       
                                        <label class="form-label">Mô tả Website</label>
                                    </div>
                                    <div class="help-info">Ví dụ : Xem anime miễn phí không quảng cáo.</div>
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="url" value="<?php echo $row["url"]; ?>" class="form-control" name="url" required>
                                        <label class="form-label">Url website</label>
                                    </div>
                                    <div class="help-info">Bắt đầu với http://, https://, ftp:// etc</div>
                                </div>
                                <button name="submit" class="btn btn-primary waves-effect" type="submit">Lưu</button>
                            </form>
                            <?php } }}?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Validation -->
        </div>
    </section>
<?php require ("./js.php"); ?>
  
</body>

</html>
<?php } ?>