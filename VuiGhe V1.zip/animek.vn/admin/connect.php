<?php
include ("../config.php");
?>
<style>
    .table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td, .table > tbody > tr > td, .table > tfoot > tr > td {
    padding: 8px;
    line-height: 1.42857143;
    vertical-align: top;
    border-top: 1px solid #ddd;
    font-size: 14px;
}
::-webkit-scrollbar{display:none}
::-webkit-scrollbar-track{display:none}
::-webkit-scrollbar-thumb{display:none;}
</style>