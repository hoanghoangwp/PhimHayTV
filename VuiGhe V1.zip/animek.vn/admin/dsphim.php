
<?php
header('Content-Type: text/html;charset=utf-8');  
ob_start();
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
if((isset($_GET['aniraw']))){
    $aniraw = $_GET['aniraw'];
    
?>

<?php require ("./connect.php"); ?>
<?php if (isset($_SESSION['user_id'])) { ?>
<!DOCTYPE html>
<html>
        <!-- JQuery DataTable Css -->
    <link href="plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">
<?php require ("./head.php"); ?>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Vui lòng chờ...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <?php require ("menu.php"); ?>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
           
            <!-- Menu -->
            <?php require ("menu2.php"); ?>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                    &copy; 2016 - 2017 <a href="javascript:void(0);">AdminBSB - Material Design</a>.
                </div>
                <div class="version">
                    <b>Version: </b> 1.0.5
                </div>
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
       
    </section>
<section class="content">
        <div class="container-fluid">
         
            <!-- Basic Examples -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                               Quản lý tập phim
                            </h2>

                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                    <thead>
                                        <tr>
                                            <th>TẬP</th>
                                            <th>Tên tập</th>
                                            <th>ID Player</th>
                                            <th>Hành động</th>
                                        </tr>
                                    </thead>
                                
                                    <tbody>
                                         <?php
				$result = mysqli_query($ketnoi,"SELECT * FROM cactap WHERE tenphim = '$aniraw' ORDER BY id DESC LIMIT 0,99999");
				if($result)
				{
				while($row = mysqli_fetch_assoc($result))
				{
				?>
                                        <tr>
                                            <td><?php echo "".$row["tap"].""; ?></td>
                                            <td><!--<img style="width: 150px;float: left;vertical-align: unset;" src="<?php echo "".$row["thumb"].""; ?>"/>--><?php echo "".$row["tentap"].""; ?></td>
                                            <td><?php echo "".$row["player"].""; ?></td>
                                            <td><a style="color: #fff;background: #1d7b62;border-color: #1d7b62;font-size: 14px;padding: 4px;" href="edittap.php?aniraw=<?php echo "".$row["id"].""; ?>"><i class="fa fa-pencil" aria-hidden="true"></i> Sửa tập phim</a></td>
                                            
                                        </tr>
                                       	<?php 
				}
				}
				?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
          
        </div>
    </section>


    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Jquery DataTable Plugin Js -->
    <script src="plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/tables/jquery-datatable.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>

	<?php } else {
		header("Location: index.php");
	} ?>
	<?php } ?>