 <div class="menu">
                <ul class="list">
                    <li class="header">Quản lý Website</li>
                    <li class="active">
                        <a href="index.php">
                            <i class="material-icons">home</i>
                            <span>Dashbroad</span>
                        </a>
                    </li>
                    <li>
                        <a href="info.php">
                            <i class="material-icons">text_fields</i>
                            <span>Sửa Info Site</span>
                        </a>
                    </li>
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">widgets</i>
                            <span>Phim</span>
                        </a>
                        <ul class="ml-menu">
                             <li>
                                <a href="danhsach.php">Danh sách & quản lý phim</a>
                            </li>
                            <li> <a href="phimbo.php">Thêm Anime (Series dài tập)</a></li>
                              <li><a href="phimle.php">Thêm Anime (MOVIE/OVA)</a></li>
                              
                        </ul>
                    </li>
                    <li>
                        <a href="logout.php">
                            <i class="material-icons">person_outline</i>
                            <span>Đăng xuất</span>
                        </a>
                    </li>
                </ul>
            </div>