
<?php 
session_start();
require ("./connect.php"); ?>
<?php if (isset($_SESSION['user_id'])) { ?>
<!DOCTYPE html>
<html>
<?php require ("./head.php"); ?>

    <!-- JQuery DataTable Css -->
    <link href="plugins/jquery-datatable/skin/bootstrap/css/dataTables.bootstrap.css" rel="stylesheet">
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Vui lòng chờ...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <?php require ("menu.php"); ?>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
           
            <!-- Menu -->
            <?php require ("menu2.php"); ?>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                    &copy; 2016 - 2017 <a href="javascript:void(0);">AdminBSB - Material Design</a>.
                </div>
                <div class="version">
                    <b>Version: </b> 1.0.5
                </div>
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
       
    </section>

    <section class="content">
        <div class="container-fluid">
           
            <!-- Basic Examples -->
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>
                               Danh sách phim
                            </h2>
                           
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-bordered table-striped table-hover js-basic-example dataTable">
                                    <thead>
                                        <tr>
                                            <th>Tên phim</th>
                                            <th>Số tập phim</th>
                                            <th>Loại phim</th>
                                            <th>Bình luận</th>
                                         
                                            <th>Quản lý</th>
                                        </tr>
                                    </thead>
                                  
                                    <tbody>
                                       <?php
				$result = mysqli_query($ketnoi,"SELECT * FROM film ORDER BY id DESC");
				if($result)
				{
				while($row = mysqli_fetch_assoc($result))
				{
				?>
                                        <tr>
                                            <td style="width: 50%;"><?php echo "".$row["tenphim"].""; ?></td>
                                            <td><?php $video = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `tap` FROM `cactap` WHERE `tenphim` = '".$row["id"]."' "));  echo $video; ?> / <?php echo "".$row["tongsotap"].""; ?></td>
                                            <td><?php if($row['loaiphim'] == 'phimbo'){ echo "Phim bộ";}else{ echo "Movie/OVA";} ?></td>
                                            <td><?php $cmt = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `binhluan` WHERE `phim` = '".$row["id"]."' "));  echo $cmt; ?></td>
                                           
                                           					<td>
					    <?php if($row['loaiphim'] == 'phimbo'){
					echo '<a  target="_blank"  title="Thêm tập phim" style="color: #fff;background: #0f5ed8;border-color: #0f5ed8;font-size: 14px;padding: 4px;" href="themtapphim.php?aniraw='.$row["id"].'"><i class="fa fa-plus" aria-hidden="true"></i></a>';
					} ?>
					<a  style="color: #fff;background: #d80f16;border-color: #d80f16;font-size: 14px;padding: 4px;" onclick="if (confirm('Bạn có chắc chắc muốn xóa phim <?php echo "".$row["tenphim"].""; ?>?')) window.location.href='xoaphim.php?idremove=<?php echo "".$row["id"].""; ?>';" href="#"><i class="fa fa-trash" aria-hidden="true"></i></a>
					<a  target="_blank" style="color: #fff;background: #1d7b62;border-color: #1d7b62;font-size: 14px;padding: 4px;" href="editphim.php?aniraw=<?php echo "".$row["id"].""; ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a>
					<?php if($row['loaiphim'] == 'phimbo'){
					echo '	<a style="color: #fff;background: #922d8e;border-color: #922d8e;font-size: 14px;padding: 4px;" href="dsphim.php?aniraw='.$row["id"].'"><i class="fa fa-list-alt" aria-hidden="true"></i></a>';
					} ?>
				</td>
                                        </tr>
                                        	<?php 
				}
				}
				?>
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Jquery DataTable Plugin Js -->
    <script src="plugins/jquery-datatable/jquery.dataTables.js"></script>
    <script src="plugins/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/dataTables.buttons.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/buttons.flash.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/jszip.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/pdfmake.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/vfs_fonts.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/buttons.html5.min.js"></script>
    <script src="plugins/jquery-datatable/extensions/export/buttons.print.min.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/tables/jquery-datatable.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>
   
</body>

</html>
<?php } ?>