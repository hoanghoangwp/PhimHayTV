 <section class="content">
        <div class="container-fluid">
   

            <!-- Widgets -->

            <div class="row clearfix">
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-pink hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">playlist_add_check</i>
                        </div>
                        <div class="content">
                            <div class="text">TỔNG SỐ PHIM</div>
                            <div class="number count-to" data-from="0" data-to="<?php $cmt = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `film` "));  echo number_format(" $cmt;") ?>" data-speed="15" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-cyan hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">help</i>
                        </div>
                        <div class="content">
                            <div class="text">TỔNG SỐ TẬP</div>
                            <div class="number count-to" data-from="0" data-to="<?php $cmt = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `cactap` "));  echo number_format(" $cmt;") ?>" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                            <?php
            $sql = "SELECT * FROM thongtin";
  mysql_query("set names 'utf8'");
$result = $conn->query($sql);
if ($result->num_rows > 0) 
{
    while($row = $result->fetch_assoc()) {
?>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-light-green hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">forum</i>
                        </div>
                        <div class="content">
                            <div class="text">BÌNH LUẬN</div>
                            <div class="number count-to" data-from="0" data-to="<?php $cmt = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `binhluan` "));  echo number_format(" $cmt;") ?>" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-orange hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">person_add</i>
                        </div>
                        <div class="content">
                            <div class="text">LƯỢT XEM TRANG</div>
                            <div class="number count-to" data-from="0" data-to="<?php echo "".$row["luotxem"].""; ?>" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
  }
} 
else {
    echo "Không có record nào";
}
 
// ngắt kết nối
$conn->close();
?>
         

            <div class="row clearfix">
                <!-- Task Info -->
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>THỐNG KÊ 5 VIDEO GẦN ĐÂY</h2>
                            <ul class="header-dropdown m-r--5">
                                <li class="dropdown">
                                    <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                        <i class="material-icons">more_vert</i>
                                    </a>
                                    <ul class="dropdown-menu pull-right">
                                        <li><a href="javascript:void(0);">Action</a></li>
                                        <li><a href="javascript:void(0);">Another action</a></li>
                                        <li><a href="javascript:void(0);">Something else here</a></li>
                                    </ul>
                                </li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover dashboard-task-infos">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Tên</th>
                                            <th>Số lượt xem</th>
                                            <th>Số bình luận</th>
                                            <th>Loại phim</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                          <?php
				$result = mysqli_query($ketnoi,"SELECT * FROM film ORDER BY id DESC limit 0,5");
				if($result)
				{
				while($row = mysqli_fetch_assoc($result))
				{
				?>
                                        <tr>
                                            <td><?php echo "".$row["id"].""; ?></td>
                                            <td><?php echo "".$row["tenphim"].""; ?></td>
                                            <td><span class="label bg-green"><?php echo "".$row["luotxem"].""; ?></span></td>
                                            <td><span class="label bg-blue"><?php $cmt = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `id` FROM `binhluan` WHERE `phim` = '".$row["id"]."' "));  echo $cmt; ?></span></td>
                                            <td>
                                                <?php if($row['loaiphim'] == 'phimbo'){ echo "Phim bộ";}else{ echo "Movie/OVA";} ?>
                                            </td>
                                        </tr>
                                     
                                        </tr>
                                        	<?php 
				}
				}
				?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- #END# Task Info -->
               
            </div>
        </div>
    </section>