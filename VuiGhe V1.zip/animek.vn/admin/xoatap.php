<?php
header('Content-Type: text/html;charset=utf-8');  
ob_start();
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
if((isset($_GET['idremove']))){
    $idremove = $_GET['idremove'];
    if((isset($_GET['vohuunhan']))){
    $vohuunhan = $_GET['vohuunhan'];
    
?>
<?php
include('../config.php');
// sql to delete a record
$sql = "DELETE FROM cactap WHERE tap=$idremove";
$conn->query('UPDATE film SET tapmoinhat = tapmoinhat - 1 WHERE id = ' . $vohuunhan);
if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
    header('Location: dsphim.php?aniraw='.$vohuunhan.'');
exit;
} else {
    echo "Xóa không thành công, lỗi : " . $conn->error;
}}

$conn->close();}

?>