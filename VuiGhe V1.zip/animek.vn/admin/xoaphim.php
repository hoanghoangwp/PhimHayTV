<?php
header('Content-Type: text/html;charset=utf-8');  
ob_start();
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
if((isset($_GET['idremove']))){
    $idremove = $_GET['idremove'];
    
?>
<?php
include('../config.php');
// sql to delete a record
$sql = "DELETE FROM film WHERE id=$idremove";
$sql1 = "DELETE FROM cactap WHERE tap=$idremove";
if ($conn->query($sql) === TRUE) {
    echo "Record deleted successfully";
    header('Location: danhsach.php');
exit;
} else {
    echo "Xóa không thành công, lỗi : " . $conn->error;
}
if ($conn->query($sql1) === TRUE) {
    echo "Record deleted successfully";
    header('Location: danhsach.php');
exit;
} else {
    echo "Xóa không thành công, lỗi : " . $conn->error;
}

$conn->close();}

?>