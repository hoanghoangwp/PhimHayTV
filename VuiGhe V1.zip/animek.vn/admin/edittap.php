<?php
header('Content-Type: text/html;charset=utf-8');  
ob_start();
session_start();
date_default_timezone_set('Asia/Ho_Chi_Minh');
if((isset($_GET['aniraw']))){
    $aniraw = $_GET['aniraw'];
    
?>
<?php require ("./connect.php"); ?>
<?php if (isset($_SESSION['user_id'])) { ?>
<?php require ("./head.php"); ?>
<body class="theme-red">
    <!-- Page Loader -->
    <div class="page-loader-wrapper">
        <div class="loader">
            <div class="preloader">
                <div class="spinner-layer pl-red">
                    <div class="circle-clipper left">
                        <div class="circle"></div>
                    </div>
                    <div class="circle-clipper right">
                        <div class="circle"></div>
                    </div>
                </div>
            </div>
            <p>Vui lòng chờ...</p>
        </div>
    </div>
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    <div class="search-bar">
        <div class="search-icon">
            <i class="material-icons">search</i>
        </div>
        <input type="text" placeholder="START TYPING...">
        <div class="close-search">
            <i class="material-icons">close</i>
        </div>
    </div>
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <?php require ("menu.php"); ?>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
           
            <!-- Menu -->
            <?php require ("menu2.php"); ?>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                    &copy; 2016 - 2017 <a href="javascript:void(0);">AdminBSB - Material Design</a>.
                </div>
                <div class="version">
                    <b>Version: </b> 1.0.5
                </div>
            </div>
            <!-- #Footer -->
        </aside>
        <!-- #END# Left Sidebar -->
       
    </section>
 <section class="content">
        <div class="container-fluid">
            <?php
$sql4 = "SELECT * FROM cactap WHERE id = '$aniraw'";
if($result1 = mysqli_query($ketnoi, $sql4)){
    if(mysqli_num_rows($result1) > 0){
        while($row = mysqli_fetch_array($result1)){
            ?>
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="card">
                        <div class="header">
                            <h2>Chỉnh sửa thông tin tập <?php echo $row["tentap"]; ?></h2>
                          
                        </div>
                        <div class="body">
 
                            <form id="form_advanced_validation" action="" method="POST">
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <center>
                                       <img class="img-responsive thumbnail" style="width: 20%;" src="<?php echo $row["thumb"]; ?>"/>
                                       </center>
                                    </div>
                                   
                                </div>
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input type="text" class="form-control" name="tentap" value="<?php echo $row["tentap"]; ?>" required>
                                        <label class="form-label">Tên của tập</label>
                                    </div>
                                    
                                </div>
                               
                                <div class="form-group form-float">
                                    <div class="form-line">
                                        <input id="sharelink" name="sharelink" type="text" value="https://drive.google.com/file/d/<?php echo $row["player"]; ?>/view?usp=sharing" class="form-control"  required>
                                        <label class="form-label">Link Player (Google Drive)</label>
                                    </div>
                                   
                                </div>
                                <div style="display:none" class="form-group form-float">
                                    <div class="form-line">
                                        <input id="player" name="player" type="text" class="form-control"  value="<?php echo $row["player"]; ?>" required>
                                        <label class="form-label">Link Player (Google Drive)</label>
                                    </div>
                                   
                                </div>
                              
                                      
                                
<button name="save" class="btn btn-primary waves-effect" type="submit">Lưu tập <?php echo $row["tentap"]; ?></button>
                                
                            </form>
                            <?php } }}?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Basic Validation -->
        </div>
    </section>
      
	</div>



<?php
$tentap = "";
$player = "";
if(isset($_POST['save'])) {
    if(isset($_POST["tentap"])) { $tentap = $_POST['tentap']; }
    if(isset($_POST["player"])) { $player = $_POST['player']; }
    $sql = "UPDATE `cactap` SET `tentap` = N'".$tentap."',`player` = N'".$player."' WHERE id = '$aniraw'";

    if (mysqli_query($conn, $sql)) {
      header("Refresh:0");
    } else {
       header("Refresh:0");
    }
mysqli_close($conn);
}



?>

 <script id="rendered-js">
          (function ($) {
  $(function () {
    var $shareLink = $('#sharelink'),
    $player = $('#player'),
    $copyButton = $('#copylinkbtn'),
    clipboard;

    $shareLink.on('keyup paste', function () {
      var link = $shareLink.val(),
      l = link.replace(/https?:\/\/drive.google.com\/file\/d\/(.+)\/(.+)/, "$1");
      if (l !== link) {
        $player.val(l);
        $copyButton.removeAttr('disabled');
      } else {
        $player.val('');
        $copyButton.attr('disabled', 'disabled');
      }
    });

    $player.on('click', function () {
      $player.select();
    });

    clipboard = new Clipboard('#copylinkbtn');
    clipboard.on('success', function (e) {
      $.notify({
        icon: 'glyphicon glyphicon-ok-circle',
        title: 'Link copied to clipboard:',
        message: e.text,
        url: e.text,
        target: '_blank' },
      {
        // settings
        type: "success",
        placement: {
          from: "top",
          align: "center" } });



      // $.notify(e.text + " copied to clipboard.");

      e.clearSelection();
    });

  });
})(jQuery);
          //# sourceURL=pen.js
        </script>
<?php require ("./js.php"); ?>
</body>
</html>
 <?php
}} ?>
