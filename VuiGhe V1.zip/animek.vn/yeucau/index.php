<?php

include ("../config.php");
$sql = "SELECT tieude, mota, url FROM thongtin";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     while($row = $result->fetch_assoc()) {
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <base href="<?php echo $row['url'] ; ?>">
	<title>Yêu cầu phim - Animek</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta name="_token" id="token" value="Ym19jTmvrimiknp3ptz9YdFE3k3XvThi0CDUqfCU">
    <meta name="_socket" id="socket" value="6001">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta http-equiv="cache-control" content="max-age=0" />
	<meta http-equiv="cache-control" content="no-cache" />
	<meta name="robots" content="index, follow" />
	<meta name="language" content="Vietnamese, English" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	
	<link rel="shortcut icon" href="<?php echo $row['url'] ; ?>/favicon.ico" type="image/x-icon" />

	<meta name="description" content="<?php echo $row['mota'] ; ?>" />
	<meta name="keywords" content="anime vietsub, xem anime, vui ghe, naruto, vua hai tac, one piece, hoi phap su, fairy tail, bleach, dragon ball, dao hai tac" />

	<!-- Facebook Metadata /-->
	<meta property="fb:app_id" content="196545913738468" />
	<meta property="og:image" content="https://i.imacdn.com/web-thumbnail.png" />
	<meta property="og:url" content="<?php echo $row['url'] ; ?>" />
	<meta property="og:description" content="<?php echo $row['mota'] ; ?>" />
	<meta property="og:title" content="<?php echo $row['tieude'] ; ?>" />
	<meta property="og:site_name" content="<?php echo $row['tieude'] ; ?>" />
	<meta property="og:type" content="video.movie" />

	<!-- Google+ Metadata /-->
	<meta itemprop="name" content="<?php echo $row['tieude'] ; ?>" />
	<meta itemprop="description" content="<?php echo $row['mota'] ; ?>" />
	<meta itemprop="image" content="https://i.imacdn.com/web-thumbnail.png" />

			<!-- Google webmaster tools verification -->
		<meta name="google-site-verification" content="X6wTJolQe36XUJJeyIxqPMs9YJ0dqJXfDdy1yksGNhA" />
		<!-- Bing verification -->
		<meta name="msvalidate.01" content="C21FDE84CE65ABA807746F89A0D2964C" />


  <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=vietnamese" rel="stylesheet">


	<link rel="stylesheet" href="<?php echo $row['url'] ; ?>/css/NhanDz.css?<?php echo date('l jS \of F Y h:i:s A'); ?>">
	        <link rel="stylesheet" href="<?php echo $row['url'] ; ?>/css/user.css?<?php echo date('l jS \of F Y h:i:s A'); ?>">

	        </head>
<?php
}
} else {
    echo "0 results";
}
$conn->close();
?>
<?php include ("../includes/menu.php"); ?>
<div class="container">

    <div class="user-page">


        <div class="user-page-body">
<?php
if(isset($_POST['yeucau']))
{
$tenphim = $_POST['tenphim'];
$tenban =  $_POST['tenban'];
$sql = "INSERT INTO yeucau (tenphim, tenban)
VALUES (N'$tenphim', N'$tenban')";
mysql_query("set names 'utf-8'");
if(mysqli_query($link, $sql)){
    echo "<script>swal('Thành công!', 'Đã yêu cầu phim $tenphim thành công!', 'success');</script>";
} else{
    echo "<script>swal('Thất bại!', 'Yêu cầu phim $tenphim không thành công!', 'error');</script>";
}

}
?>
<style class="cp-pen-styles">table { 
	width: 100%; 
	border-collapse: collapse; 
	}

/* Zebra striping */
tr:nth-of-type(odd) { 
	background: #eee; 
	}

th { 
	background: #3498db; 
	color: white; 
	}

td, th { 
padding: 10px;
    border: 1px solid #ccc;
    text-align: left;
    font-size: 14px;
    font-weight: 400;
	}

/* 
Max width before this PARTICULAR table gets nasty
This query will take effect for any screen smaller than 760px
and also iPads specifically.
*/
@media 
only screen and (max-width: 760px),
(min-device-width: 768px) and (max-device-width: 1024px)  {

	table { 
	  	width: 100%; 
	}

	/* Force table to not be like tables anymore */
	table, thead, tbody, th, td, tr { 
		display: block; 
	}
	
	/* Hide table headers (but not display: none;, for accessibility) */
	thead tr { 
		position: absolute;
		top: -9999px;
		left: -9999px;
	}
	
	tr { border: 1px solid #ccc; }
	
	td { 
		/* Behave  like a "row" */
		border: none;
		border-bottom: 1px solid #eee; 
		position: relative;
		padding-left: 50%; 
	}

	td:before { 
		/* Now like a table header */
		position: absolute;
		/* Top/left values mimic padding */
		top: 6px;
		left: 6px;
		width: 45%; 
		padding-right: 10px; 
		white-space: nowrap;
		/* Label the data */
		content: attr(data-column);

		color: #000;
		font-weight: bold;
	}

}</style>
			<form method="POST" action="" class="form-horizontal">
			                    
			    <div class="form-group">
			        <label for="username">Tên phim</label>
                    <input id="input" type="text" placeholder="Ví dụ : Date A Live" required="" name="tenphim" value="">
			    </div>

			    <div class="form-group">
			        <label for="full_name">Tên bạn</label>
                    <input type="text" id="input1" placeholder="Ví dụ : Võ Hữu Nhân" required="" name="tenban" >
			    </div>


			    <div class="form-group">
                    <button name="yeucau" type="submit">Gửi yêu cầu</button>
			    </div>
			</form>
<table>
  <thead>
    <tr>
      <th>Tên người yêu cầu</th>
      <th>Tên phim yêu cầu</th>
      <th>Thời gian yêu cầu</th>
      <th>Trạng thái yêu cầu</th>
    </tr>
  </thead>
  <tbody>
       <?php
				$result = mysqli_query($ketnoi,"SELECT * FROM yeucau ORDER BY reg_date ASC");
				if($result)
				{
				while($row = mysqli_fetch_assoc($result))
				{
				?>
    <tr>
      <td data-column="Tên người YC"><?php echo "".$row["tenban"].""; ?></td>
      <td data-column="Tên phim"><?php echo "".$row["tenphim"].""; ?></td>
      <td data-column="Thời gian YC"><?php echo "".$row["reg_date"].""; ?></td>
      <td data-column="Trạng thái">Chờ duyệt phim</td>
    </tr>
  <?php 
				}
				}
				?>
  </tbody>
</table>

				                    
		</div>
	</div>
</div>


    <div class="floating-action">
	<div class="action-item action-toggle"><i class="icon-assistive"></i></div>
	<div class="action-item action-home"><i class="icon-home"></i></div>
	<div class="action-item action-menu"><i class="icon-menu"></i></div>
	<div class="action-item action-user"><i class="icon-person"></i></div>
	<div class="action-item action-top"><i class="icon-up"></i></div>
</div>    

    
    <script type="text/javascript" src="<?php echo $row['url'] ; ?>/js/bhome.js?id=d5d6742d3990dc111882"></script>

																											<div id="balloon">
						
						</div>
																				
						
<script>
$("#input").keypress(function(event) {
    var character = String.fromCharCode(event.keyCode);
    return isValid(character);     
});

function isValid(str) {
    return !/[~`!@#$%\^&*()+=\-\[\]\\';,/{}|\\":<>\?]/g.test(str);
}
</script>
	<script>
$("#input1").keypress(function(event) {
    var character = String.fromCharCode(event.keyCode);
    return isValid(character);     
});

function isValid(str) {
    return !/[~`!@#$%\^&*()+=\-\[\]\\';,/{}|\\":<>\?]/g.test(str);
}
</script>    	
</body>
</html>

