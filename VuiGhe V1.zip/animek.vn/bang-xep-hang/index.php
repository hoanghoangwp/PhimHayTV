<?php

include ("../config.php");
$sql = "SELECT tieude, mota, url FROM thongtin";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
     while($row = $result->fetch_assoc()) {
?>
<!DOCTYPE html>
<html lang="vi">
<head>
  <base href="<?php echo $row['url'] ; ?>">
	<title>Bảng xếp hạng - Animek</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
    <meta name="_token" id="token" value="Ym19jTmvrimiknp3ptz9YdFE3k3XvThi0CDUqfCU">
    <meta name="_socket" id="socket" value="6001">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<meta http-equiv="cache-control" content="max-age=0" />
	<meta http-equiv="cache-control" content="no-cache" />
	<meta name="robots" content="index, follow" />
	<meta name="language" content="Vietnamese, English" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

	
	<link rel="shortcut icon" href="<?php echo $row['url'] ; ?>/favicon.ico" type="image/x-icon" />

	<meta name="description" content="<?php echo $row['mota'] ; ?>" />
	<meta name="keywords" content="anime vietsub, xem anime, vui ghe, naruto, vua hai tac, one piece, hoi phap su, fairy tail, bleach, dragon ball, dao hai tac" />

	<!-- Facebook Metadata /-->
	<meta property="fb:app_id" content="196545913738468" />
	<meta property="og:image" content="https://i.imacdn.com/web-thumbnail.png" />
	<meta property="og:url" content="<?php echo $row['url'] ; ?>" />
	<meta property="og:description" content="<?php echo $row['mota'] ; ?>" />
	<meta property="og:title" content="<?php echo $row['tieude'] ; ?>" />
	<meta property="og:site_name" content="<?php echo $row['tieude'] ; ?>" />
	<meta property="og:type" content="video.movie" />

	<!-- Google+ Metadata /-->
	<meta itemprop="name" content="<?php echo $row['tieude'] ; ?>" />
	<meta itemprop="description" content="<?php echo $row['mota'] ; ?>" />
	<meta itemprop="image" content="https://i.imacdn.com/web-thumbnail.png" />

			<!-- Google webmaster tools verification -->
		<meta name="google-site-verification" content="X6wTJolQe36XUJJeyIxqPMs9YJ0dqJXfDdy1yksGNhA" />
		<!-- Bing verification -->
		<meta name="msvalidate.01" content="C21FDE84CE65ABA807746F89A0D2964C" />


  <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&amp;subset=vietnamese" rel="stylesheet">


	<link rel="stylesheet" href="<?php echo $row['url'] ; ?>/css/NhanDz.css?<?php echo date('l jS \of F Y h:i:s A'); ?>">
	        <link rel="stylesheet" href="<?php echo $row['url'] ; ?>/css/list.css?<?php echo date('l jS \of F Y h:i:s A'); ?>">

	        </head>
<?php
}
} else {
    echo "0 results";
}
$conn->close();
?>
<?php include ("../includes/menu.php"); ?>
<div class="container">
   <!-- <div class="slider-wrapper">
    
        <div class="slider-container" data-u="slides">
            
                
                    <img class="slider-single" src="http://i.imacdn.com/slider/2016/01/25337c7bf2774a5da499ec734df4135c.jpg">
                
            
        </div>
    
</div>-->
        <!-- Latest episodes -->
        <section class="tray rank">
          
          <div class="tray-content index">
               
 <?php
				$result = mysqli_query($ketnoi,"SELECT * FROM film ORDER BY luotxem DESC LIMIT 0,99999");
				if($result)
				{
				while($row = mysqli_fetch_assoc($result))
				{
				?>
                              <a href="https://animek.vn/View/id/<?php echo "".$row["linkphim"].""; ?>.html?play=<?php echo "".$row["id"].""; ?>"> <div class="tray-item">
  
   
					<img class="tray-item-thumbnail" src="<?php echo "".$row["thumbnail"].""; ?>" data-src="<?php echo "".$row["thumbnail"].""; ?>" alt="'<?php echo "".$row["tenphim"].""; ?>">';

					
      
      <div class="tray-item-description">
          <div class="tray-item-title"><?php echo "".$row["tenphim"].""; ?></div>
          <div class="tray-item-meta-info">
<?php echo number_format("".$row["luotxem"].""); ?> lượt xem 
              <!--<span class="tray-episode-views"></span>-->
          </div>
      </div>
     <!-- <div class="tray-film-genres">
                        <span><?php echo "".$row["theloai"].""; ?></span>                    </div>-->
                       
                    <?php $video = mysqli_num_rows(mysqli_query($ketnoi,"SELECT `tap` FROM `cactap` WHERE `tenphim` = '".$row["id"]."' "));   ?>
            
      <div class="tray-item-play-button">
          
          <i class="icon-play"></i>
      </div>
      <?php if($row['loaiphim'] == 'sapchieu'){
					echo '<div class="tray-item-upcoming">SẮP CHIẾU</div>';
					} ?>
					<?php if($row['loaiphim'] == 'phimbo'){
					echo '<div class="tray-item-upcoming">PHIM BỘ '.$video.'/'.$row["tongsotap"].'</div>';
					} ?>
					<?php if($row['loaiphim'] == 'phimle'){
					echo '<div class="tray-item-upcoming">PHIM LẺ '.$video.'/'.$row["tongsotap"].'</div>';
					} ?>
      
           
</div>   </a>
                            	<?php 
				}
				}
				?>
                         </div>



    <div class="floating-action">
	<div class="action-item action-toggle"><i class="icon-assistive"></i></div>
	<div class="action-item action-home"><i class="icon-home"></i></div>
	<div class="action-item action-menu"><i class="icon-menu"></i></div>
	<div class="action-item action-user"><i class="icon-person"></i></div>
	<div class="action-item action-top"><i class="icon-up"></i></div>
</div>    

    
    <script type="text/javascript" src="<?php echo $row['url'] ; ?>/js/bhome.js?id=d5d6742d3990dc111882"></script>

																											<div id="balloon">
						
						</div>
																				
						
    	
	    	
</body>
</html>

